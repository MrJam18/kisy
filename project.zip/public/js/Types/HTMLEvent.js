export {};
//# sourceMappingURL=HTMLEvent.js.map