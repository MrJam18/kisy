export function searchButtonClickHandler() {
    const searchInput = document.querySelector('.search-input');
    searchInput.classList.add('search-input_focus');
    searchInput.focus();
}
//# sourceMappingURL=searchButtonClickHandler.js.map