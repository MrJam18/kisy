export const standardTransition = 200;
//# sourceMappingURL=standardTransition.js.map