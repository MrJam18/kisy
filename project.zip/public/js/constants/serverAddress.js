export const serverAddress = 'http://localhost:8000/api/';
//# sourceMappingURL=serverAddress.js.map