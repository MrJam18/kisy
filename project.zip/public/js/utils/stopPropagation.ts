export function stopPropagation (ev: Event) {
    ev.stopPropagation();
}